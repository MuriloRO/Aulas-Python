# Data-Science
Este repositório serve para o estudo de Data Science.

O codigo foi feito seguindo o video (https://youtu.be/vmEHCJofslg) e foi escrito em portugues para facilitar o entendimento.
